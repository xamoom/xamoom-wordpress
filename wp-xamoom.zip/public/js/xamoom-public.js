(function( $ ) {
	'use strict';

	/**
	 * Nothing to see here.
	 */

})( jQuery );
