=== xamoom ===

Contributors:      xamoom
Plugin Name:       xamoom
Plugin URI:        http://xamoom.com
Tags:              location, content, xamoom, leaflet, map, spots, spot, page, beacon, range, nfc, rfid, cms
Author URI:        http://xamoom.com
Author:            xamoom GmbH
Donate link:       xamoom.com
Requires at least: 4.5
Requires PHP:      5.2.4
Tested up to:      5.1.1
Stable tag:        1.0.0
Version:           1.0.0
== Description ==
This plugin allows you to sync xamoom pages to Wordpress. The plugin is offered as 
a service. You need an API key provided by xamoom. 
Terms of Service: https://xamoom.com/terms-of-service/.
== Installation ==
Paste your api key in the appropriate settings field